# Family Mapping App - Quick Start

## Windows Users:
1. Install Docker Desktop from: https://www.docker.com/products/docker-desktop
2. Double-click `start-app-hub.bat`
3. Open browser to: http://localhost:8765
4. To stop: Double-click `stop-app-hub.bat`

## Mac/Linux Users:
1. Install Docker Desktop from: https://www.docker.com/products/docker-desktop
2. Open Terminal in this folder
3. Run: `./start-app-hub.sh`
4. Open browser to: http://localhost:8765
5. To stop: Run `./stop-app-hub.sh`

## Need Help?
See README.md for detailed instructions and troubleshooting.

Your data will be saved in a 'datasets' folder that will be created automatically.
